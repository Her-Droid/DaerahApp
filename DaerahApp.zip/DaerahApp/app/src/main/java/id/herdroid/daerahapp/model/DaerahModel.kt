package id.herdroid.daerahapp.model

data class DaerahModel(
    var id: String = "",
    var place: String = ""
)
