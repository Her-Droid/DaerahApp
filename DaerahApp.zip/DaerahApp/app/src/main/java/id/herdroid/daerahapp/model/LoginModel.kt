package id.herdroid.daerahapp.model

data class LoginModel(
    var user_name: String = "",
    var password: String = ""
)
