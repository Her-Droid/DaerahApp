package id.herdroid.daerahapp.model

data class UserModel(
    var email: String = "",
    var password: String = "",
    var noTelp: String = "",
    var customerName: String ="",
    var sukses:Boolean = false
)
